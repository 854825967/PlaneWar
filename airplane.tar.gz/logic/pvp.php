<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class pvp extends action {
    public function test() {
        echo GROOVE::GROOVE_NOTHING;
    }
    
    //args::   grv_pos:groove position, equip_id:equip id
    public function replace() {
        
    }
    
    public function getDefier() {
        
    }
    
    public function getTop20() {
        
    }
    
    public function attack() {
        
    }
}