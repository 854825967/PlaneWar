<?php

    class uinfo extends action{
        
        public function getUinfo () {
            if(!isset($_GET['uid'])||!isset($_GET['ptoken'])){
                $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
            }else {
                $m = GetModule("/ext/mem");
                $ptoken = $m->getone($_GET['uid'],'ptoken');
                if($ptoken != $_GET['ptoken']) {
                    $res['code'] = error_code('ERROR_CODE_P_TOKEN_ERROR');     
                }else {
                    $db = GetModule("/ext/db");
                    $info = $db->getUinfo($_GET['uid']);
                    if(!$info) {
                        $res['code'] = error_code('ERROR_CODE_DB_NO_RESULTS');
                    }else {
                        $name = $m->getone($_GET['uid'],'name');
                        $info['name'] = $name;
                        $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                        $res['data'] = $info;
                    }
                }   
            }
            echo json_encode($res);
        }
        
        public function updateUinfo () {
            
        }
        
        
    }

