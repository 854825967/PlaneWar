<?php

    class sell extends action {
       
        //出售装备接口
        public function sellE (){
            if(!isset($_GET['uid'])||!isset($_GET['ptoken'])||!isset($_GET['eids'])){
                $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
            }else {
                $m = GetModule("/ext/mem");
                $ptoken = $m->getone($_GET['uid'],'ptoken');
                if($ptoken != $_GET['ptoken']) {
                    $res['code'] = error_code('ERROR_CODE_P_TOKEN_ERROR');     
                }else {
                    $eids = (string)'"' . $_GET['eids'] . '"';
                    $n = substr_count($eids, ',') + 1;
                    $db = GetModule("/ext/db"); 
                    $info = $db->sellE($_GET['uid'],$n,$eids);
                    if($info['code'] === '0') {
                        $res['code'] = error_code('ERROR_CODE_DIRTY_DATA');
                    }elseif($info['m']) {
                        $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                        $res['money'] = (int)$info['m'];
                    }
                }
            }
            log_trace($res);
            echo json_encode($res);
        }
    }

