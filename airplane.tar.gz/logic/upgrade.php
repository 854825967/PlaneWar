<?php
    class upgrade extends action {

            //出售装备接口
            public function upgradeE() {
                if(!isset($_GET['uid'])||!isset($_GET['ptoken'])||!isset($_GET['eids'])){
                    $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
                }else {
                    $m = GetModule("/ext/mem");
                    $ptoken = $m->getone($_GET['uid'],'ptoken');
                    if($ptoken != $_GET['ptoken']) {
                        $res['code'] = error_code('ERROR_CODE_P_TOKEN_ERROR');     
                    }else {
                        $eid = substr($_GET['eids'],0,strpos($_GET['eids'],","));
                        $eids = (string)'"' . $_GET['eids'] . '"';
                        $n = substr_count($eids, ',') + 1;
                        if($n>6){
                            $res['code'] =  error_code('ERROR_CODE_UPGRADE_ERROR');
                        }else {
                            $db = GetModule("/ext/db"); 
                            $info = $db->getEids($_GET['uid'],$n,$eids);
                            if($info[0]['code'] === '0') {
                                $res['code'] = error_code('ERROR_CODE_DIRTY_DATA');
                            }else {
                                for($i = 0,$exp = 0;$i < $n;$i++){
                                    if($info[$i]['equipid'] == $eid){
                                        $s = $info[$i]['status'];
                                        $t = $info[$i]['type'];
                                        $elevel = $info[$i]['level'];
                                        $eexp = $info[$i]['exp'];
                                    }else {
                                        $exps = $exps + ($info[$i]['level']*($info[$i]['level'] - 1)*($info[$i]['level'] + 38) * 0.8 + 400);
                                    }
                                }
                                $m = ($n - 1) * ($elevel + 20);
                                $eexp = floor($eexp + $exps);
                                for($l = $elevel,$e = $eexp ;$e >= $l*($l - 1)*($l + 38); $l++) {
                                }
                                $elevel = $l - 1;
                                $eids = str_replace($eid.",", "", $eids);
                                $db1 = GetModule("/ext/db");
                                $rs = $db1->upgradeE($_GET['uid'],$eid,$eexp,$elevel,$eids,$m);
                                if($rs['m'] === '0') {
                                    $res['code'] = error_code('ERROR_CODE_MONEY_NOT_ENOUGH');
                                }else {
                                    if($s = 1) {
                                        $g_m = GetModule("/ext/equip_mem");
                                        $grooves = $g_m->getGrooves();
                                        switch ($t) {
                                            case 0: 
                                                $grooves['plane']['level'] = $elevel;
                                                $catk1 = $grooves['plane']['batk'] + ($grooves['plane']['level']-1)*($grooves['plane']['batk']/20);
                                                break;
                                            case 1:
                                                $grooves['armor']['level'] = $elevel;
                                                $clife = $grooves['armor']['barmor'] + ($grooves['armor']['level']-1)*($grooves['armor']['armor']/200);
                                                break;
                                            case 2:
                                                $grooves['weapon']['level'] = $elevel;
                                                $catk2 = $grooves['weapon']['batk'] + ($grooves['wepon']['level']-1)*($grooves['weapon']['batk']/20);
                                                break;
                                            case 3:
                                                $grooves['wingman']['level'] = $elevel;
                                                $catk3 = $grooves['wingman']['batk'] + ($grooves['wingman']['level']-1)*($grooves['wingman']['batk']/20);
                                                break;
                                        }
                                        $grooves['capacity'] = floor($grooves['plane']['catk'] + $grooves['armor']['carmor']/20 + $grooves['weapon']['catk'] + $grooves['wingman']['catk']);
                                        $g_m->setGrooves($grooves);
                                        $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                                        $res['money'] = (int)$rs['m'];
                                        $res['eid'] = (int)$eid;
                                        $res['level'] = $elevel;
                                        $res['exp'] = $eexp;
                                    }
                                }
                            }
                        }
                    }
                }
                echo json_encode($res);
            }
        }

