<?php

    class tourist extends action{
        //游客登陆接口
		public function tlogin () {
			if($_GET['user'] != 'tourist'){
				$res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
			} else {				
				/*
				$s = 'abcdefghijklmnopqrstuvwxyz';
				$i = rand(0,25);
				$a = substr($s,$i,1);
				$uid = $a . rand(100000000,999999999);
				*/
				$uid = rand(100000000,999999999);
				$uid = (string)$uid;
				$token = '1234567890';
				$time = time();
				$str = $uid . $token . $time;
				$ptoken = md5($str);
				$t = "游客";
				$name = $t . $uid;
				$m = GetModule("/ext/mem");
                		$m->saveuinfo($uid, $name, $token, $ptoken);
				$res['code'] = error_code('ERROR_CODE_NO_ERROR');
				$res['uid'] = $uid;
				$res['name'] = $name;
				$res['ptoken'] = $ptoken;				
			}
			echo json_encode($res);
		}
		
		
		
    }
