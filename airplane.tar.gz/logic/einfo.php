<?php

    class einfo extends action {
        
        //获取用户所有装备信息
        /*
        public function getEinfo () {
            if(!isset($_GET['uid'])||!isset($_GET['ptoken'])){
                $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
            }else {
                $m = GetModule("/ext/mem");
                $ptoken = $m->getone($_GET['uid'],'ptoken');
                if($ptoken != $_GET['ptoken']) {
                    $res['code'] = error_code('ERROR_CODE_P_TOKEN_ERROR');     
                }else {
                    $db = GetModule("/ext/db");
                    $info = $db->getEinfo($_GET['uid']);
                    if(!$info) {
                        $res['code'] = error_code('ERROR_CODE_DB_NO_RESULTS');
                    }else {
                        $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                        $res['count'] = count($info);
                        $res['equipments'] = $info;
                    }   
                }
            }
            echo json_encode($res);
        }
        */
        
        //更换装备(暂定类型大于10的不能装备,在存储过程中判断)
        /*
        public function changeE() {
            if(!isset($_GET['uid'])||!isset($_GET['ptoken'])||!isset($_GET['eid'])) {
                $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
            }else {
                $m = GetModule("/ext/mem");
                $ptoken = $m->getone($_GET['uid'],'ptoken');
                if($ptoken != $_GET['ptoken']) {
                    $res['code'] = error_code('ERROR_CODE_P_TOKEN_ERROR');     
                }else {
                    $db = GetModule("/ext/db");
                    $info = $db->changeE($_GET['eid'],$_GET['uid']);
                    if(!$info){    
                        $res['code'] = error_code('ERROR_CODE_E_CHANGE_FAILURE');
                    }else {
                        if($info['code'] === '0') {
                            $res['code'] = error_code('ERROR_CODE_DIRTY_DATA');
                        }else  {
                            $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                            
                        }
                    }   
                }
            }
//            $tmp = "{$_GET['eid']}" . '|' . "{$res['code']}";
//            log_debug($tmp);
            echo json_encode($res);
        }
         * *
         */
        
        public function getEinfo () {
            if(!isset($_GET['uid'])||!isset($_GET['ptoken'])){
                $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
            }else {
                $m = GetModule("/ext/mem");
                $ptoken = $m->getone($_GET['uid'],'ptoken');
                if($ptoken != $_GET['ptoken']) {
                    $res['code'] = error_code('ERROR_CODE_P_TOKEN_ERROR');     
                }else {
                    $db = GetModule("/ext/db");
                    $info = $db->getEinfo($_GET['uid']);
                    if(!$info) {
                        $res['code'] = error_code('ERROR_CODE_DB_NO_RESULTS');
                    }else {
                        foreach ($info as $k => $v) {
                            if($info[$k]['status'] == 1) {
                                switch ($info[$k]['type']) {
                                    case 0: 
                                        $p = xml2array("./pcfg/Plane/{$info[$k]['modelname']}.xml");
                                        $catk1 = $p['atk'] + ($info[$k]['level']-1)*($p['atk']/20);
                                        $plane = array(
                                            'eid' => $info[$k]['equipid'],
                                            'type' => $info[$k]['type'],
                                            'model' => $info[$k]['modelname'],
                                            'level' => $info[$k]['level'],
                                            'batk' => $p['atk'],
                                            'catk' => $catk1
                                        );
                                        break;
                                    case 1:
                                        $a = xml2array("./pcfg/Armor/{$info[$k]['modelname']}.xml");
                                        $clife = $a['armor'] + ($info[$k]['level']-1)*($a['armor']/200);
                                        $armor = array(
                                            'eid' => $info[$k]['equipid'],
                                            'type' => $info[$k]['type'],
                                            'model' => $info[$k]['modelname'],
                                            'level' => $info[$k]['level'],
                                            'barmor' => $a['armor'],
                                            'carmor' => $clife
                                        );
                                        break;
                                    case 2:
                                        $we = xml2array("./pcfg/Weapon/{$info[$k]['modelname']}.xml");
                                        $catk2 = $we['atk'] + ($info[$k]['level']-1)*($we['atk']/20);
                                        $weapon = array(
                                            'eid' => $info[$k]['equipid'],
                                            'type' => $info[$k]['type'],
                                            'model' => $info[$k]['modelname'],
                                            'level' => $info[$k]['level'],
                                            'batk' => $we['atk'],
                                            'catk' => $catk2
                                        );
                                        break;
                                    case 3:
                                        $wi = xml2array("./pcfg/Wingman/{$info[$k]['modelname']}.xml");
                                        $catk3 = $wi['atk'] + ($info[$k]['level']-1)*($wi['atk']/20);
                                        $wingman = array(
                                            'eid' => $info[$k]['equipid'],
                                            'type' => $info[$k]['type'],
                                            'model' => $info[$k]['modelname'],
                                            'level' => $info[$k]['level'],
                                            'batk' => $wi['atk'],
                                            'catk' => $catk3
                                        );
                                        break;
                                }
                            }
                        }
                        $capacity = floor($catk1 + $catk2 + $catk3 + $clife/20);
                        $grooves = array(
                            'plane' => $plane,
                            'armor' => $armor,
                            'weapon' => $weapon,
                            'wingman' => $wingman,
                            'capacity' => $capacity
                        );
                        $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                        $res['count'] = count($info);
                        $res['equipments'] = $info;
                        $g_m = GetModule("/ext/equip_mem");
                        $g_m->setGrooves($grooves);
                    }   
                }
            }
            echo json_encode($res);
        }
        
        public function changeE() {
            if(!isset($_GET['uid'])||!isset($_GET['ptoken'])||!isset($_GET['eid'])) {
                $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
            }else {
                $m = GetModule("/ext/mem");
                $ptoken = $m->getone($_GET['uid'],'ptoken');
                if($ptoken != $_GET['ptoken']) {
                    $res['code'] = error_code('ERROR_CODE_P_TOKEN_ERROR');     
                }else {
                    $db = GetModule("/ext/db");
                    $info = $db->changeE($_GET['eid'],$_GET['uid']);
                    if(!$info){    
                        $res['code'] = error_code('ERROR_CODE_E_CHANGE_FAILURE');
                    }else {
                        if($info['code'] === '0') {
                            $res['code'] = error_code('ERROR_CODE_DIRTY_DATA');
                        }else  {
                            $g_m = GetModule("/ext/equip_mem");
                            $grooves = $g_m->getGrooves();
                            switch ($info['type']) {
                                case 0:
                                    $p = xml2array("./pcfg/Plane/{$info['modelname']}.xml");
                                    $catk1 = $p['atk'] + ($info['level']-1)*($p['atk']/20);
                                    $grooves['plane']['eid'] = $info['equipid'];
                                    $grooves['plane']['type'] = $info['type'];
                                    $grooves['plane']['model'] = $info['modelname'];
                                    $grooves['plane']['level'] = $info['level'];
                                    $grooves['plane']['batk'] = $p['atk'];
                                    $grooves['plane']['catk'] = $catk1;
                                    break;
                                case 1:
                                    $a = xml2array("./pcfg/Armor/{$info['modelname']}.xml");
                                    $clife = $a['armor'] + ($info['level']-1)*($a['armor']/200);
                                    $grooves['armor']['eid'] = $info['equipid'];
                                    $grooves['armor']['type'] = $info['type'];
                                    $grooves['armor']['model'] = $info['modelname'];
                                    $grooves['armor']['level'] = $info['level'];
                                    $grooves['armor']['barmor'] = $a['armor'];
                                    $grooves['armor']['carmor'] = $clife;
                                    break;
                                case 2:
                                    $we = xml2array("./pcfg/Weapon/{$info['modelname']}.xml");
                                    $catk2 = $we['atk'] + ($info['level']-1)*($we['atk']/20);
                                    $grooves['weapon']['eid'] = $info['equipid'];
                                    $grooves['weapon']['type'] = $info['type'];
                                    $grooves['weapon']['model'] = $info['modelname'];
                                    $grooves['weapon']['level'] = $info['level'];
                                    $grooves['weapon']['batk'] = $we['atk'];
                                    $grooves['weapon']['catk'] = $catk2;
                                    break;
                                case 3:
                                    $wi = xml2array("./pcfg/Wingman/{$info['modelname']}.xml");
                                    $catk3 = $wi['atk'] + ($info['level']-1)*($wi['atk']/20);
                                    $grooves['wingman']['eid'] = $info['equipid'];
                                    $grooves['wingman']['type'] = $info['type'];
                                    $grooves['wingman']['model'] = $info['modelname'];
                                    $grooves['wingman']['level'] = $info['level'];
                                    $grooves['wingman']['batk'] = $wi['atk'];
                                    $grooves['wingman']['catk'] = $catk3;
                                    break;
                            }
                            $grooves['capacity'] = floor($grooves['plane']['catk'] + $grooves['armor']['carmor']/20 + $grooves['weapon']['catk'] + $grooves['wingman']['catk']);
                            $g_m->setGrooves($grooves);
                            $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                        }
                    }   
                }
            }
//            $tmp = "{$_GET['eid']}" . '|' . "{$res['code']}";
//            log_debug($tmp);
            echo json_encode($res);
        }
        
    }