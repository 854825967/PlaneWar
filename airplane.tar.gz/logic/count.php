<?php

    class count extends action {
       
        //pve结算接口
        public function countpve (){
            if(!isset($_GET['uid'])||!isset($_GET['ptoken'])||!isset($_GET['gamelevel'])){
                $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
            }else {
                $m = GetModule("/ext/mem");
                $ptoken = $m->getone($_GET['uid'],'ptoken');
                if($ptoken != $_GET['ptoken']) {
                    $res['code'] = error_code('ERROR_CODE_P_TOKEN_ERROR');     
                }else {
                    $es = array(
                        array('type'=>0,'modelname'=>'zhanshenyihao','level'=>1,'exp'=>0),
                        array('type'=>1,'modelname'=>'bazhuahudun','level'=>1,'exp'=>0),
                        array('type'=>2,'modelname'=>'jiutoushedujian','level'=>1,'exp'=>0),
                        array('type'=>3,'modelname'=>'qingtianbazhua','level'=>1,'exp'=>0),

                        array('type'=>0,'modelname'=>'xunleijianfeng','level'=>1,'exp'=>0),
                        array('type'=>2,'modelname'=>'wujinchuanjiadan','level'=>1,'exp'=>0),
                        array('type'=>3,'modelname'=>'sidanjiguanpao','level'=>1,'exp'=>0)
                    );
                    $n = array_rand($es,1);
                    $db = GetModule("/ext/db"); 
                    $info = $db->addone($_GET['uid'],$es[$n]['type'],$es[$n]['modelname'],$es[$n]['level'],$es[$n]['exp']);
                    if(!$info) {
                        $res['code'] = error_code('ERROR_CODE_DB_NO_RESULTS');
                    }else {
                        $data = $es[$n];
                        $data['equipid'] = $info['eid'];
                        $data['status'] = "0";
                        $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                        $res['data'] = $data;
                    }
                }
            }
        echo json_encode($res);
        }
    }

