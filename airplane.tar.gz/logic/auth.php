<?php
    $path = $_SERVER['DOCUMENT_ROOT'];
    require_once $path . '/ext/sinasdk/saetv2.ex.class.php';
    require_once $path . '/ext/sinasdk/config.php';
    
    class auth extends action{
        //普通方式登录
        public function nlogin () {
            if(!isset($_GET['uid'])||!isset($_GET['token'])){
                $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
            }else {
                $c = new SaeTClientV2( WB_AKEY , WB_SKEY , $_GET['token'] );
                $detail = $c->show_user_by_id($_GET['uid']);
                if(!$detail['id']) {
                    $res['code'] = error_code('ERROR_CODE_SINA_USER_NOT_EXIST'); //从新浪查询无此用户
                } else {
                    $arr['uid'] = $_GET['uid'];
                    $arr['name'] = $detail['screen_name'];
                    $arr['token'] = $_GET['token'];
                    $time = time();
                    $str = $arr['uid'] . $arr['token'] . $time;
                    $arr['ptoken'] = md5($str);
                    $m = GetModule("/ext/mem");
                    $m->saveuinfo($arr['uid'], $arr['name'], $arr['token'], $arr['ptoken']);

                    $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                    $res['uid'] = $arr['uid'];
                    $res['ptoken'] = $arr['ptoken'];
                }
            }
            echo json_encode($res);
            
        }


		//快速登陆接口
        public function qlogin () {
            if(!isset($_GET['uid'])||!isset($_GET['ptoken'])){
                $res['code'] = error_code('ERROR_CODE_ARGS_ERROR');
            } else {
                $m = GetModule("/ext/mem");
                $ptoken = $m->getone($_GET['uid'],'ptoken');
                if($ptoken === $_GET['ptoken']) {
                    $res['code'] = error_code('ERROR_CODE_NO_ERROR');
                } else {
                    $res['code'] = error_code('ERROR_CODE_P_TOKEN_ERROR'); //本地memcached里没有该用户或ptoken不符
                }
            }
            echo json_encode($res);
        }
		
		
    }
