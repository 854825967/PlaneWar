<?php

class mem {
    
    protected $mem;
            
    public function getKeyname($name) {
        $keyname = "{$name}:{$_GET['uid']}";
        return $keyname;
    }


    public function __construct() {
        $this->mem = new Memcache();
        $this->mem->connect(config('MEMCACHE_HOST'),config('MEMCACHE_PORT')); 
        //$this->mem->connect(localhost,11211); 
        
    }
    
    //保存用户信息，存储的信息如下
    //键名：$uid  键值：array （$name,$token,$ptoken）
    public function saveuinfo ($uid, $name, $token, $ptoken) {
        $arr = array('name'=>$name,
                    'token'=>$token,
                    'ptoken'=>$ptoken);
        $this->mem->set($uid,$arr,0,config('MEMCACHE_TIME'));
        //$this->mem->set($uid,$arr,0,600);
    }

    //获取memcached里用户的一个信息
    //args:$uid,想获取的键$k
    //res:false,$k对应的键值
    public function getone ($uid, $k) {
        $arr = $this->mem->get($uid);
        if(empty($arr)) {
            return FALSE;
        }else {
            return $arr[$k];
        }
    }
    
    public function getrow ($key) {
        $arr = $this->mem->get($key);
        if(empty($arr)) {
            return FALSE;
        }else {
            return $arr;
        }
    }

    //更新memcached里用户信息
    //args:$uid,需要修改的属性名$k,需要修改的值$v；若不存在此属性，则自动新增
    public function updateone ($uid, $k, $v) {
        $arr = $this->mem->get($uid);
        if(empty($arr)) {
            return FALSE;
        }else {
            $arr[$k] = $v;
            $this->mem->set($uid,$arr,0,config('MEMCACHE_TIME'));
        }
    }
    
  
    public function __destruct() {
        $this->mem->close();
    }
}

?>