<?php

class db {

    protected $con = null;
    protected $rs = null;

    public function __construct() {
        define('CLIENT_MULTI_RESULTS', 131072);
        $this->con = mysql_connect(config('MYSQL_SERVER_NAME'), config('MYSQL_USERNAME'), config('MYSQL_PASSWORD'),1,CLIENT_MULTI_RESULTS);
        if (!$this->con) {
            logerror("DB_CONNECT_FAILD");
        }
        mysql_select_db(config('MYSQL_DATABASE'));
    }

    //获取用户基本信息
    //args：$uid
    //res:array,false
    public function getUinfo($uid) {
        $sql = "call proc_getUinfo($uid);";
        $rs = mysql_query($sql);
        if (!$rs) {
            return FALSE;
        }
        return mysql_fetch_assoc($rs);
    }

    //获取用户所有装备信息
    //args:$uid
    //res:array,false
    public function getEinfo($uid) {
        $sql = "call proc_getEinfo($uid);";
        $rs = mysql_query($sql);
        if (!$rs) {
            return FALSE;
        }
        $list = array();
        while ($row = mysql_fetch_assoc($rs)) {
            $list[] = $row;
        }
        return $list;
    }

    
    //更换装备
    //args:$eid,$uid,$t(类型),$s（状态）
    //res:true,false
    public function changeE($eid, $uid) {
        $sql = "call proc_changeE($eid, $uid);";
        $rs = mysql_query($sql);
        if ($rs===true) {
            return FALSE;
        } else {
            return mysql_fetch_array($rs);
        }
    }
    
    //出售装备
    //args:$uid,$n(装备个数)，$eids(装备id组成的字符串)
    //res:单一值，false
    public function sellE($uid, $n, $eids) {
        $sql = "call proc_sellE($uid, $n, $eids)";
        $rs = mysql_query($sql);
        if (!$rs) {
            return FALSE;
        }else {
            return mysql_fetch_assoc($rs);
        }
    }

    //获取装备
    //args:$uid,$n,$edis
    //res:array
    public function getEids($uid, $n, $eids) {
        $sql = "call proc_getEids($uid, $n, $eids)";
        $rs = mysql_query($sql);
        if (!$rs) {
            return FALSE;
        }else {
            $list = array();
            while ($row = mysql_fetch_assoc($rs)) {
                $list[] = $row;
            }
            return $list;
        }
    }
    
    //强化装备
    //args:$uid,$eid,$eexp,$elevel,$eids,$m
    //res:单一值，false
    public function upgradeE($uid, $eid, $eexp, $elevel, $eids, $m) {
        $sql = "call proc_upgradeE($uid,$eid,$eexp,$elevel,$eids,$m)";
        $rs = mysql_query($sql);
        if (!$rs) {
            return FALSE;
        }else {
            return mysql_fetch_assoc($rs);
        }
    }
    
    //增加一件装备
    //args:
    //res:
    public function addone($uid, $type, $modelname, $level, $exp) {
        $sql = "call proc_addoneE('$uid',$type,'$modelname',$level,$exp)";
        $rs = mysql_query($sql);
        if(!$rs) {
            return FALSE;
        }else {
            return mysql_fetch_assoc($rs);
        }
    }

    public function __destruct() {
        mysql_close($con);
        exit();
    }

}
