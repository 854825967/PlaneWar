<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once 'mem.php';

class equip_mem extends mem {
    private $grooves = array(
        "plane" => array(
            "eid" => "",
            "type" => "",
            "model" => "",
            "level" => "",
            "batk" => "",
            "catk" => ""
        ),

        "weapon" => array(
            "eid" => "",
            "type" => "",
            "model" => "",
            "level" => "",
            "barmor" => "",
            "carmor" => ""  
        ),
        
        "armor" => array(
            "eid" => "",
            "type" => "",
            "model" => "",
            "level" => "",
            "batk" => "",
            "catk" => ""
        ),
        
        "wingman" => array(
            "eid" => "",
            "type" => "",
            "model" => "",
            "level" => "",
            "batk" => "",
            "catk" => ""
        ),
        
        "capacity" =>""
    );
    
    public function getGrooves() {
        $grooves = $this->mem->get($this->getKeyname("grooves"));
        return $grooves;
    }
    public function setGrooves($grooves) {
        $this->mem->set($this->getKeyname("grooves"), $grooves , 0, config('MEMCACHE_TIME'));
    }
    
    
    
    
}

