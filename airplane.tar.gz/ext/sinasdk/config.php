<?php
header('Content-Type: text/html; charset=UTF-8');

//SmartStar
//define( "WB_AKEY" , '3357260630' );
//define( "WB_SKEY" , '5b994580e0da1ed387a04f6321fafed7' );
//define( "WB_CALLBACK_URL" , 'https://api.weibo.com/oauth2/default.html' );



//大蜀山动物园
//回调地址http://127.0.0.1/sinasdk/callback.php
//define( "WB_AKEY" , '1790594633' );
//define( "WB_SKEY" , 'a6151b54018b2b8a166b8ba47367aacd' );
//define( "WB_CALLBACK_URL" , '127.0.0.1/sinasdk/callback.php' );

//飞机大战
//回调地址
define( "WB_AKEY" , '2654936299' );
define( "WB_SKEY" , 'cfcdc3c8b2f69d18ccccf8b2cb94f0c7' );
define( "WB_CALLBACK_URL" , 'https://api.weibo.com/oauth2/default.html' );

//链接数据库
//$link=mysql_connect('localhost','root','');
//mysql_select_db("test", $link);

