<?php

require_once "{$_SERVER['DOCUMENT_ROOT']}/info/config.php";
require_once "{$_SERVER['DOCUMENT_ROOT']}/info/error.php";
require_once "{$_SERVER['DOCUMENT_ROOT']}/info/define.php";
require_once "{$_SERVER['DOCUMENT_ROOT']}/ext/mem.php";
require_once "{$_SERVER['DOCUMENT_ROOT']}/tools.php";
require_once "{$_SERVER['DOCUMENT_ROOT']}/action.php";

if (!config('DEBUG')) {
    error_reporting(0);
}
session_start();

call($_SERVER['PATH_INFO']);

?>
