<?php
    class action extends mem{
        function action() {
            
        }
    }
?>
