<?php

function config($index) {
    $config = array(
        //trace_log switch
        'TRACE' => TRUE,
        //debug model switch
        'DEBUG' => TRUE,
        //memcache config
        'MEMCACHE_HOST' => "localhost",
        'MEMCACHE_PORT' => 11211,
        'MEMCACHE_TIME' => 0, //设置memcache过期时间，0为永久有效
        //mysql config
        'MYSQL_SERVER_NAME' => "localhost",
        'MYSQL_USERNAME' => "root",
        'MYSQL_PASSWORD' => "",
        'MYSQL_DATABASE' => "airplane",
    );
    
    return $config[$index];
}

