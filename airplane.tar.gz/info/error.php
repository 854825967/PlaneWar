<?php
function error_code($index){
    $error_code = array (
        'ERROR_CODE_UNKNOWN' => 0,
        'ERROR_CODE_NO_ERROR' => 1,
        'ERROR_CODE_ARGS_ERROR' => 2,
        'ERROR_CODE_SINA_USER_NOT_EXIST' => 3,
        'ERROR_CODE_P_TOKEN_ERROR' => 4,
        'ERROR_CODE_DB_NO_RESULTS' => 5,
        'ERROR_CODE_E_CHANGE_FAILURE' => 6,
        'ERROR_CODE_DIRTY_DATA' => 7,
        'ERROR_CODE_UPGRADE_ERROR' => 8,
        'ERROR_CODE_MONEY_NOT_ENOUGH' => 9
    );
    
    return $error_code[$index];
}
?>
