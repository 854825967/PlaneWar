<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class GROOVE {
    const GROOVE_NOTHING = 0;
    const GROOVE_PVE = 1;
    const GROOVE_PVP_MAIN_ATK = 2;
    const GROOVE_PVP_SUB_ATK = 3;
    const GROOVE_PVP_ARMOR = 4;
}
