<?php 
	$link=mysql_connect("localhost","root",""); 
	if(!$link) {
		die(mysql_error());
	} else {
		echo "link ok";
	}
 

